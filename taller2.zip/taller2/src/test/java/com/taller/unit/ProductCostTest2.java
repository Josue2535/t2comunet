package com.taller.unit;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.example.model.prod.Product;
import com.example.model.prod.Productcategory;
import com.example.model.prod.Productcosthistory;
import com.example.model.prod.Productsubcategory;
import com.example.model.prod.Unitmeasure;
import com.taller.boot.Taller1Application;
import com.taller.repository.interfaces.ProductCategoryRepository;
import com.taller.repository.interfaces.ProductCostHisoryRepository;
import com.taller.repository.interfaces.ProductRepository;
import com.taller.repository.interfaces.ProductSubCategoryRepository;
import com.taller.service.implementations.ProductCategoryServiceIMPL;
import com.taller.service.implementations.ProductCostHistoryServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ProductSupCategoryServiceIMPL;
import com.taller.service.interfaces.ProductCategoryService;
import com.taller.service.interfaces.ProductService;
import com.taller.service.interfaces.ProductSupCategoryService;



@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = Taller1Application.class)
@TestInstance(Lifecycle.PER_CLASS)
class ProductCostTest2 {

	@Mock
	public ProductRepository productRepository;
	
	@Mock
	public ProductCostHisoryRepository repo;
	
	// ------------------------------------------------------------------------------------------
	
	@InjectMocks
	public ProductCostHistoryServiceIMPL ser;
	
	
	
	// ------------------------------------------------------------------------------------------
	
	public Product product;
	
	public Productcosthistory pch;
	
	// ------------------------------------------------------------------------------------------
	
	@BeforeEach
	public void setup1() {
		
		pch = new Productcosthistory();
		product = new Product();
		//productService.save(product, productCategory.getProductcategoryid(), productSubCategory.getProductsubcategoryid(), Integer.parseInt(unitmeasure.getUnitmeasurecode()));
		
	}
	
	// ------------------------------------------------------------------------------------------
	
	@Nested
	class saveProductTest{
		
		@Test
		@DisplayName("Save a null")
		public void savePCHTest1() {
			
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(NullPointerException.class,() -> ser.save(null));
			
		}
		@Test
		@DisplayName("Instancia del precio histórico del producto con la fecha inicio mayor a la fecha fin.")
		public void savePCHTest2() {
			Long datetime = System.currentTimeMillis();
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datetime);
			pch.setEnddate(null);
			assertThrows(NullPointerException.class,() -> ser.save(null));
		}
		@Test
		@DisplayName("Instancia del precio histórico del producto con el precio negativo.")
		public void savePCHTest3() {
			pch.setId(1);
			pch.setStandardcost((long) -1);
			assertThrows( RuntimeException.class,() -> ser.save(pch));
		}
		@Test
		@DisplayName("Id de un producto que no existe.")
		public void savePCHTest4() {
			pch.setId(-1);
			pch.setStandardcost((long) 1);
			assertThrows( RuntimeException.class,() -> ser.save(pch));
		}
		@Test
		@DisplayName("Instancia del precio histórico del producto con la información correcta.")
		public void savePCHTest5() {
			pch.setId(1);
			pch.setStandardcost((long) 1);
			pch.setProduct(product);
			product.setProductid(1);
			assertThrows( StackOverflowError.class,() -> ser.save(pch));
			
		}
		
		//------------ TEST UP DATE --------------------------------------------
		
		@Test
		@DisplayName("Id, y precio histórico del producto nulo.")
		public void upDatePCHTest1() {
			
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(NullPointerException.class,() -> ser.update(null,1));
			
		}
		
		@Test
		@DisplayName("actualizando un producto sin numero de producto")
		public void upDatePCHTest2() {
			
		}
		
		@Test
		@DisplayName("Id, y la instancia del precio histórico del producto con la fecha de inicio mayor a la actuals")
		public void upDatePCHTest3() {
			pch.setId(1);
			pch.setStandardcost((long) 1);
			assertThrows(NullPointerException.class,() -> ser.update(pch,1));
		}
		@Test
		@DisplayName("Id que no existe, y la instancia del precio histórico del producto con la información correcta.")
		public void upDatePCHTest4() {
			pch.setId(1);
			pch.setStandardcost((long) 1);
			assertThrows(NullPointerException.class,() -> ser.update(pch,1));
		}
		
		
	}
	
	
}
