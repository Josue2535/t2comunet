package com.taller.unit;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.example.model.prod.Product;
import com.example.model.prod.Productcategory;
import com.example.model.prod.Productsubcategory;
import com.example.model.prod.Unitmeasure;
import com.example.model.sales.Shoppingcartitem;
import com.taller.boot.Taller1Application;
import com.taller.repository.interfaces.ProductCategoryRepository;
import com.taller.repository.interfaces.ProductRepository;
import com.taller.repository.interfaces.ProductSubCategoryRepository;
import com.taller.repository.interfaces.ShoppingCartItemRepository;
import com.taller.service.implementations.ProductCategoryServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ProductSupCategoryServiceIMPL;
import com.taller.service.implementations.ShoppingCarItemServiceIMPL;
import com.taller.service.interfaces.ProductCategoryService;
import com.taller.service.interfaces.ProductService;
import com.taller.service.interfaces.ProductSupCategoryService;



@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = Taller1Application.class)
@TestInstance(Lifecycle.PER_CLASS)
class ShoppingCarItemTest2 {

	@Mock
	public ProductRepository productRepository;
	
	@Mock
	public ShoppingCartItemRepository repo;
	// ------------------------------------------------------------------------------------------
	
	@Mock
	public ProductServiceIMPL productService;
	
	@InjectMocks
	public ShoppingCarItemServiceIMPL ser;
	// ------------------------------------------------------------------------------------------
	Shoppingcartitem sci;
	
	// ------------------------------------------------------------------------------------------
	
	@BeforeEach
	public void setup1() {
		sci = new Shoppingcartitem();
		
		
		//productService.save(product, productCategory.getProductcategoryid(), productSubCategory.getProductsubcategoryid(), Integer.parseInt(unitmeasure.getUnitmeasurecode()));
		
	}
	
	// ------------------------------------------------------------------------------------------
	
	@Nested
	class saveProductTest{
		
		@Test
		@DisplayName("Instancia del ítem del carrito de compras nulo.")
		public void saveShoppingcartitemTest1() {
			
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(NullPointerException.class,() -> ser.save(null));
			
		}
		@Test
		@DisplayName("Guardando una categoria que no existe")
		public void saveShoppingcartitemTest2() {
			sci.setProductid(-1);
			assertThrows(RuntimeException.class,() -> ser.save(sci));
		}
		@Test
		@DisplayName("Guardando un producto sin numero asociado")
		public void saveShoppingcartitemTest3() {
			sci.setProductid(1);
			sci.setQuantity(0);
			assertThrows(RuntimeException.class,() -> ser.save(sci));
		}
		@Test
		@DisplayName("Instancia de un ítem del carrito de compras con la fecha de creación mayor a la actual.")
		public void saveShoppingcartitemTest4() {
			sci.setProductid(1);
			sci.setQuantity(0);
			assertThrows(RuntimeException.class,() -> ser.save(sci));
		}
		@Test
		@DisplayName("Instancia del ítem del carrito de compras con todas las condiciones cumplidas.")
		public void saveShoppingcartitemTest5() {
			sci.setProductid(1);
			sci.setQuantity(1);
			ser.save(sci);
			assertTrue(!repo.existsById(1));
			
		}
		
		//------------ TEST UP DATE --------------------------------------------
		
		@Test
		@DisplayName("Id, y una instancia del ítem del carrito de compras nulo.")
		public void upDateShoppingcartitemTest1() {
			
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(NullPointerException.class,() -> ser.update(null,1));
			
		}
		
		@Test
		@DisplayName("Id de un producto que no existe dentro del sistema")
		public void upDateShoppingcartitemTest2() {
			sci.setProductid(1);
			sci.setQuantity(0);
			assertThrows(RuntimeException.class,() -> ser.update(sci,-1));
		}
		
		@Test
		@DisplayName("Id, y una instancia de un ítem del carrito de compras con cantidad -5.")
		public void upDateShoppingcartitemTest3() {
			sci.setProductid(1);
			sci.setQuantity(-5);
			assertThrows(RuntimeException.class,() -> ser.update(sci,-1));
		}
		@Test
		@DisplayName("Id, y una instancia de un ítem del carrito de compras con cantidad -5.")
		public void upDateShoppingcartitemTest4() {
			sci.setProductid(1);
			sci.setQuantity(0);
			assertThrows(RuntimeException.class,() -> ser.update(sci,-1));
		}
		
		
	}
	
	
}
