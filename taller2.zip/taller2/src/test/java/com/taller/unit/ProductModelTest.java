package com.taller.unit;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.example.model.prod.Product;
import com.example.model.prod.Productcategory;
import com.example.model.prod.Productmodel;
import com.example.model.prod.Productsubcategory;
import com.example.model.prod.Unitmeasure;
import com.taller.boot.Taller1Application;
import com.taller.repository.interfaces.ProductCategoryRepository;
import com.taller.repository.interfaces.ProductModelRepository;
import com.taller.repository.interfaces.ProductRepository;
import com.taller.repository.interfaces.ProductSubCategoryRepository;
import com.taller.service.implementations.ProductCategoryServiceIMPL;
import com.taller.service.implementations.ProductModelServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ProductSupCategoryServiceIMPL;
import com.taller.service.interfaces.ProductCategoryService;
import com.taller.service.interfaces.ProductService;
import com.taller.service.interfaces.ProductSupCategoryService;



@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = Taller1Application.class)
@TestInstance(Lifecycle.PER_CLASS)
class ProductModelTest {

	// ------------------------------------------------------------------------------------------

				// RELACIONES CON LOS REPOSITORIOS.
				@Mock
				public ProductModelRepository productModelRepo;

				// ------------------------------------------------------------------------------------------

				// RELACIONES CON LOS SERVICIOS
				@InjectMocks
				public ProductModelServiceIMPL productModelSer;


				// ------------------------------------------------------------------------------------------

				// RELACION CON LAS DIFERENTES CLASES DEL MODELO.

				public Productmodel pm;

				// ------------------------------------------------------------------------------------------

				// ESCENARIO PRINCIPAL PARA LOS CASOS DE PRUEBA.

				@BeforeEach
				public void setup1() {

					pm = new Productmodel();

				}

				// --------------Metodos para probar el save------------------------------------------

				@Nested
				class saveProductModelTest{

					@Test
					@DisplayName("Guardar el productmodel sin ninguna informacion")
					public void saveProducModelTest1() {

						assertThrows(NullPointerException.class,() -> productModelSer.save(null));

					}

					@Test
					@DisplayName("Instancia del modelo del producto con nombre menor a 5 caracteres.")
					public void saveProductTest2() {

						pm.setName("");
						pm.setCatalogdescription("Hola este producto sirve para");
						
						assertThrows(RuntimeException.class, () -> productModelSer.save(pm));

					}

					@Test
					@DisplayName("Instancia del modelo del producto con descripción menor a 5 caracteres")
					public void saveProductModelTest3() {

						pm.setName("Hola este producto sirve para");
						pm.setCatalogdescription("");
						
						assertThrows(RuntimeException.class, () -> productModelSer.save(pm));

					}
					@Test
					@DisplayName("Instancia del modelo del producto sin nombre ni descripción.")
					public void saveProductModelTest4() {

						pm.setName("");
						pm.setCatalogdescription("");
						
						assertThrows(RuntimeException.class, () -> productModelSer.save(pm));

					}
					
					@Test
					@DisplayName("Instancia del modelo del producto con todas las condiciones cumplidas.")
					public void saveProductModelTest5() {

						pm.setName("este es el nombre");
						pm.setCatalogdescription("hola como estas");
						pm.setProductmodelid(1);
						productModelSer.save(pm);
						assertTrue(!productModelRepo.existsById(1));
						

					}
					
					//------------------------ UP DATE ------------------------------
					@Test
					@DisplayName("Id, y una Instancia del modelo sin ninguna descripción.")
					public void upDateProductModelTest1() {
						
						pm.setName("");
						pm.setCatalogdescription("");
						
						assertThrows(RuntimeException.class,() -> productModelSer.update(1, pm));
						
					}
					
					@Test
					@DisplayName("Id, Instancia del modelo nula.")
					public void upDateProductTest2() {
						pm.setName("");
						pm.setCatalogdescription("");
						
						assertThrows(RuntimeException.class,() -> productModelSer.update(1, pm));
					}
					
					@Test
					@DisplayName("Id, y una Instancia del modelo con nombre de 15 caracteres, pero con una descripción de solo 3.")
					public void upDateProductTest3() {
						pm.setName("123456789012345");
						pm.setCatalogdescription("123");
						
						assertThrows(RuntimeException.class,() -> productModelSer.update(1, pm));
					}
					@Test
					@DisplayName("Id errónea")
					public void upDateProductTest4() {
						pm.setName("123456789012345");
						pm.setCatalogdescription("12345");
						
						assertThrows(RuntimeException.class,() -> productModelSer.update(1, pm));
					}

				}
	
}
