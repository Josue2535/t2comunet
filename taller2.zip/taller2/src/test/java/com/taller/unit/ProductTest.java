package com.taller.unit;

import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Array;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.example.model.prod.Product;
import com.example.model.prod.Productcategory;
import com.example.model.prod.Productsubcategory;
import com.example.model.prod.Unitmeasure;
import com.taller.boot.Taller1Application;
import com.taller.repository.interfaces.ProductCategoryRepository;
import com.taller.repository.interfaces.ProductRepository;
import com.taller.repository.interfaces.ProductSubCategoryRepository;
import com.taller.service.implementations.ProductCategoryServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ProductSupCategoryServiceIMPL;
import com.taller.service.interfaces.ProductCategoryService;
import com.taller.service.interfaces.ProductService;
import com.taller.service.interfaces.ProductSupCategoryService;



@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ContextConfiguration(classes = Taller1Application.class)
@TestInstance(Lifecycle.PER_CLASS)
class ProductTest {

	@Mock
	public ProductRepository productRepository;
	
	@Mock
	public ProductCategoryRepository productCategoryRepository;
	
	@Mock
	public ProductSubCategoryRepository productSubCategoryRepository;
	
	// ------------------------------------------------------------------------------------------
	
	@InjectMocks
	public ProductServiceIMPL productService;
	
	@Mock
	public ProductCategoryServiceIMPL productCategoryService;
	
	@Mock
	public ProductSupCategoryServiceIMPL productSubCategoryService;
	
	// ------------------------------------------------------------------------------------------
	
	public Product product;
	
	public Productcategory productCategory;
	
	public Productsubcategory productSubCategory;
	
	// ------------------------------------------------------------------------------------------
	
	@BeforeEach
	public void setup1() {
		
		product = new Product();
		
		productCategory = new Productcategory();
		
		productSubCategory = new Productsubcategory();
		
		
		productCategory.setProductcategoryid(1);
		productCategory.setName("Gaseosas");
		productCategory.setModifieddate(new Timestamp(System.currentTimeMillis()));
		productCategory.setRowguid(425);
		
		productCategoryService.save(productCategory);
		
		productSubCategory.setProductsubcategoryid(15);
		productSubCategory.setName("Internacionales");
		productSubCategory.setModifieddate(new Timestamp(System.currentTimeMillis()));
		productSubCategory.setRowguid(78);
		
		productSubCategoryService.save(productSubCategory);
		
		product.setProductnumber("1");
		product.setName("Coca Cola");
		product.setColor("Negro");
		product.setSellstartdate(new Timestamp(System.currentTimeMillis()));
		product.setSellenddate(new Timestamp(System.currentTimeMillis()));
		product.setSize("5");
		
		Integer y = 15;
		
		product.setWeight(y.longValue());
		
		//productService.save(product, productCategory.getProductcategoryid(), productSubCategory.getProductsubcategoryid(), Integer.parseInt(unitmeasure.getUnitmeasurecode()));
		
	}
	
	// ------------------------------------------------------------------------------------------
	
	@Nested
	class saveProductTest{
		
		@Test
		@DisplayName("Save a null product")
		public void saveProductTest1() {
			
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(NullPointerException.class,() -> productService.save(null));
			
		}
		@Test
		@DisplayName("Guardando una categoria que no existe")
		public void saveProductTest2() {
			Product p = new Product();
			p.setName("Doritos");
			p.setProductid(2);
			p.setProductnumber("1");
			Long datetime = System.currentTimeMillis();
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datetime);
	        p.setSellstartdate(timestamp);
	        p.setSellenddate(timestamp2);
	        Long n = (long) 10;
	        p.setWeight(n);
	        p.setSize("40");
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(RuntimeException.class,() -> productService.save(p,10,15,1));
		}
		@Test
		@DisplayName("Guardando un producto sin numero asociado")
		public void saveProductTest3() {
			Product p = new Product();
			p.setName("Doritos");
			p.setProductid(2);
			Long datetime = System.currentTimeMillis();
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datetime);
	        p.setSellstartdate(timestamp);
	        p.setSellenddate(timestamp2);
	        Long n = (long) 10;
	        p.setWeight(n);
	        p.setSize("40");
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(RuntimeException.class,() -> productService.save(p));
		}
		@Test
		@DisplayName("Guardando un producto sin que exista la categoria")
		public void saveProductTest4() {
			Product p = new Product();
			p.setName("Doritos");
			p.setProductid(2);
			p.setProductnumber("1");
			Long datetime = System.currentTimeMillis();
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datetime);
	        p.setSellstartdate(timestamp);
	        p.setSellenddate(timestamp2);
	        Long n = (long) 10;
	        p.setWeight(n);
	        p.setSize("40");
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(RuntimeException.class,() -> productService.save(p,15,20,1));
		}
		@Test
		@DisplayName("Guardando un producto sin que exista la categoria")
		public void saveProductTest5() {
			Product p = new Product();
			p.setName("Doritos");
			p.setProductid(2);
			p.setProductnumber("1");
			Long datetime = System.currentTimeMillis();
			Long datatime2 = datetime *2;
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datatime2);
	        p.setSellstartdate(timestamp);
	        p.setSellenddate(timestamp2);
	        Long n = (long) 10;
	        p.setWeight(n);
	        p.setSize("40");
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			productService.save(p);
			assertTrue(!productRepository.existsById(p.getProductid()));
			
		}
		
		//------------ TEST UP DATE --------------------------------------------
		
		@Test
		@DisplayName("up date null product")
		public void upDateProductTest1() {
			
			//Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(NullPointerException.class,() -> productService.update(null,1));
			
		}
		
		@Test
		@DisplayName("actualizando un producto sin numero de producto")
		public void upDateProductTest2() {
			Product p = new Product();
			p.setName("Doritos");
			p.setProductid(2);
			p.setProductnumber("1");
			Long datetime = System.currentTimeMillis();
			Long datetime2 = datetime*2;
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datetime2);
	        p.setSellstartdate(timestamp);
	        p.setSellenddate(timestamp2);
	        Long n = (long) 10;
	        p.setWeight(n);
	        p.setSize("40");
	        productService.save(p);
	        p.setProductnumber(null);
	        //Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(RuntimeException.class,() -> productService.update(p,1));
		}
		
		@Test
		@DisplayName("fechas iguales")
		public void upDateProductTest3() {
			Product p = new Product();
			p.setName("Doritos");
			p.setProductid(2);
			p.setProductnumber("1");
			Long datetime = System.currentTimeMillis();
			Long datetime2 = datetime*2;
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datetime2);
	        p.setSellstartdate(timestamp);
	        p.setSellenddate(timestamp2);
	        Long n = (long) 10;
	        p.setWeight(n);
	        p.setSize("40");
	        productService.save(p);
	        p.setSellenddate(timestamp);
	        //Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(RuntimeException.class,() -> productService.update(p,1));
		}
		@Test
		@DisplayName("Producto con id falso")
		public void upDateProductTest4() {
			Product p = new Product();
			p.setName("Doritos");
			p.setProductid(2);
			p.setProductnumber("1");
			Long datetime = System.currentTimeMillis();
			Long datetime2 = datetime*2;
	        Timestamp timestamp = new Timestamp(datetime);
	        Timestamp timestamp2 = new Timestamp(datetime2);
	        p.setSellstartdate(timestamp);
	        p.setSellenddate(timestamp2);
	        Long n = (long) 10;
	        p.setWeight(n);
	        p.setSize("40");
	        productService.save(p);
	        
	        //Mockito.when(productService.save(null)).thenThrow(NullPointerException.class);
			
			assertThrows(RuntimeException.class,() -> productService.update(p,115));
		}
		
		
	}
	
	
}
