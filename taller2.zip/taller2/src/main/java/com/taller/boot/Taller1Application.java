package com.taller.boot;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;



@SpringBootApplication
@EnableJpaRepositories("com.taller.repository.interfaces")
@EntityScan(basePackages = {"com.taller.auth","com.example.model.hr","com.example.model.person","com.example.model.prchasing","com.example.model.prod","com.example.model.sales"})
@ComponentScan(basePackages = {"com.taller.auth","com.taller.repository.interfaces","com.taller.service.implementations","com.taller.controller"})
public class Taller1Application {

	public static void main(String[] args) {
		SpringApplication.run(Taller1Application.class, args);
	}
	
	@Bean
	public CommandLineRunner add() {
		return (args) -> {
			
		};
	}

}