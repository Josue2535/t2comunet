package com.taller.repository.interfaces;

import org.springframework.data.repository.CrudRepository;

import com.example.model.prod.Productmodel;

public interface ProductModelRepository extends CrudRepository<Productmodel, Integer> {

}
