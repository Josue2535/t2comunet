package com.taller.repository.interfaces;

import org.springframework.data.repository.CrudRepository;

import com.example.model.prod.Productsubcategory;

public interface ProductSubCategoryRepository extends CrudRepository<Productsubcategory, Integer>{

}
