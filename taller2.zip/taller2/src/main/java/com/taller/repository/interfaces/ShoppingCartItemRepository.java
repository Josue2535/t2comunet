package com.taller.repository.interfaces;

import org.springframework.data.repository.CrudRepository;

import com.example.model.sales.Shoppingcartitem;

public interface ShoppingCartItemRepository extends CrudRepository<Shoppingcartitem, Integer> {

}
