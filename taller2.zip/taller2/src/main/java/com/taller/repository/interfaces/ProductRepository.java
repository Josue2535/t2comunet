package com.taller.repository.interfaces;

import org.springframework.data.repository.CrudRepository;

import com.example.model.prod.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{

}
