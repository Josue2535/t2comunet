package com.taller.service.implementations;

import java.sql.Timestamp;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.prod.Product;
import com.example.model.prod.Productmodel;
import com.taller.repository.interfaces.ProductModelRepository;
import com.taller.service.interfaces.ProductModelService;
@Service
public class ProductModelServiceIMPL implements ProductModelService{
	private ProductModelRepository repo;
	@Autowired
	public ProductModelServiceIMPL(ProductModelRepository repo) {
		this.repo = repo;
	}
	@Override
	public void save(Productmodel p) {
		if(p.getName().length()>=5) {
			if(p.getCatalogdescription().length()>=5) {
				repo.save(p);
			}else {
				throw new RuntimeException("La descripcion debe tener un largo mayor a 5");
			}
		}else {
			throw new RuntimeException("El nombre tiene que tener un largo mayor a 5");
		}
		
	}

	@Override
	public void update(Integer id, Productmodel p) {
		
		if(p.getName().length()>=5) {
			if(p.getCatalogdescription().length()>=5) {
				
				
				Productmodel temp = repo.findById(id).get();
				temp.setCatalogdescription(p.getCatalogdescription());
				temp.setInstructions(p.getInstructions());
				temp.setModifieddate(p.getModifieddate());
				temp.setName(p.getName());
				temp.setProductmodelillustrations(p.getProductmodelillustrations());
				temp.setProductmodelproductdescriptioncultures(p.getProductmodelproductdescriptioncultures());
				temp.setProducts(p.getProducts());
				temp.setRowguid(p.getRowguid());
				repo.save(temp);
				
			}else {
				throw new RuntimeException("La descripcion debe tener un largo mayor a 5");
			}
		}else {
			throw new RuntimeException("El nombre tiene que tener un largo mayor a 5");
		}
	}
	public Iterable<Productmodel> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	public Optional<Productmodel> findById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}
	public void delete(Productmodel productmodel) {
		// TODO Auto-generated method stub
		repo.delete(productmodel);
	}
	

}
