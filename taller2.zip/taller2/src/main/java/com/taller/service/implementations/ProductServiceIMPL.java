package com.taller.service.implementations;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.prod.Product;
import com.example.model.prod.Productsubcategory;
import com.taller.repository.interfaces.ProductCategoryRepository;
import com.taller.repository.interfaces.ProductRepository;
import com.taller.service.interfaces.ProductCategoryService;
import com.taller.service.interfaces.ProductService;
import com.taller.service.interfaces.ProductSupCategoryService;
@Service
public class ProductServiceIMPL implements ProductService {
	private ProductRepository repo;
	private ProductSupCategoryService supSer;
	private ProductCategoryService catSer;
	@Autowired
	public ProductServiceIMPL(ProductRepository repo, ProductSupCategoryService supSer, ProductCategoryService catSer) {
		this.repo = repo;
		this.supSer = supSer;
		this.catSer = catSer;
	}

	@Override
	public void save(Product p) {
		if (p.getProductnumber() != null) {
			if (p.getSellstartdate().before(p.getSellenddate())) {
				if (p.getWeight() > 0) {
					if (Integer.parseInt(p.getSize()) > 0) {

						repo.save(p);

					} else {
						throw new RuntimeException("No tiene el tamaño adecuado");
					}
				} else {
					throw new RuntimeException("No tiene el peso adecuado");
				}
			} else {
				throw new RuntimeException("fecha de inicio mayor a la fecha de fin");
			}
		} else {
			throw new RuntimeException("No tiene product numero");
		}

	}

	@Override
	public void update(Product p, int id) {
		if (p.getProductnumber() != null) {
			if (p.getSellstartdate().before(p.getSellenddate())) {
				if (p.getWeight() > 0) {
					if (Integer.parseInt(p.getSize()) > 0) {
						if (supSer.exist(p.getProductsubcategory().getProductsubcategoryid()) && catSer
								.exist(p.getProductsubcategory().getProductcategory().getProductcategoryid())) {
							repo.deleteById(id);
							repo.save(p);
						} else {
							throw new RuntimeException("categoria o supcategoria no existen");
						}
					} else {
						throw new RuntimeException("No tiene el tamaño adecuado");
					}
				} else {
					throw new RuntimeException("No tiene el peso adecuado");
				}
			} else {
				throw new RuntimeException("fecha de inicio mayor a la fecha de fin");
			}
		} else {
			throw new RuntimeException("No tiene product numbre");
		}

	}

	@Override
	public void save(Product p, int supCategory, int category, int codigo) {
		if (p.getProductnumber() != null) {
			if (p.getSellstartdate().before(p.getSellenddate())) {
				if (p.getWeight() > 0) {
					if (Integer.parseInt(p.getSize()) > 0) {

						if(supSer.exist(supCategory)) {
							if(catSer.exist(category)) {
								if(!repo.existsById(codigo)) {
									repo.save(p);
								}else {
									throw new RuntimeException("el codigo ya existe");
								}
							}else {
								throw new RuntimeException("la categoria no existe");
							}
						}else {
							throw new RuntimeException("la sup categoria no existe");
						}

					} else {
						throw new RuntimeException("No tiene el tamaño adecuado");
					}
				} else {
					throw new RuntimeException("No tiene el peso adecuado");
				}
			} else {
				throw new RuntimeException("fecha de inicio mayor a la fecha de fin");
			}
		} else {
			throw new RuntimeException("No tiene product numbre");
		}
		
	}

	@Override
	public boolean exist(int id) {
		// TODO Auto-generated method stub
		return repo.existsById(id);
	}

	public Iterable<Product> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public Optional<Product> findById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	public void delete(Product product) {
		// TODO Auto-generated method stub
		repo.deleteById(product.getProductid());
	}

	
	
	


}
