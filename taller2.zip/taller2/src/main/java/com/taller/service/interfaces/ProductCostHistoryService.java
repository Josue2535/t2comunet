package com.taller.service.interfaces;

import org.springframework.stereotype.Service;

import com.example.model.prod.Productcosthistory;

@Service
public interface ProductCostHistoryService {
	public void save(Productcosthistory pch);
	public void update(Productcosthistory pch, int id);
}
