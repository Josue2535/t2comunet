package com.taller.service.interfaces;

import org.springframework.stereotype.Service;

import com.example.model.sales.Shoppingcartitem;

@Service
public interface ShoppingCarItemService {
	public void save(Shoppingcartitem sc);
	public void update(Shoppingcartitem sc, int id);
}
