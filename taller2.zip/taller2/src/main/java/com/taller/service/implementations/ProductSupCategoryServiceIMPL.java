package com.taller.service.implementations;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.prod.Product;
import com.example.model.prod.Productcategory;
import com.example.model.prod.Productsubcategory;
import com.taller.repository.interfaces.ProductSubCategoryRepository;
import com.taller.service.interfaces.ProductSupCategoryService;
@Service
public class ProductSupCategoryServiceIMPL implements ProductSupCategoryService {
	private ProductSubCategoryRepository repo;
	
	
	@Autowired
	public ProductSupCategoryServiceIMPL(ProductSubCategoryRepository repo) {
		this.repo = repo;
	}

	@Override
	public void save(Productsubcategory psc) {
		repo.save(psc);
		
	}

	@Override
	public void update(Productsubcategory psc, int id) {
		repo.deleteById(psc.getProductsubcategoryid());
		repo.save(psc);
		
	}

	@Override
	public void addProduct(Product p, int id) {
		repo.findById(id).get().addProduct(p);
		
	}

	@Override
	public boolean exist(Integer productsubcategoryid) {
		// TODO Auto-generated method stub
		return repo.existsById(productsubcategoryid);
	}

	public Iterable<Productsubcategory> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public Optional<Productsubcategory> findById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	public void delete(Productsubcategory productsubcategory) {
		// TODO Auto-generated method stub
		repo.deleteById(productsubcategory.getProductsubcategoryid());
	}
	
	

	

}
