package com.taller.service.interfaces;

import org.springframework.stereotype.Service;

import com.example.model.prod.Productmodel;
@Service
public interface ProductModelService {
	public void save(Productmodel p);
	public void update(Integer id, Productmodel p);
}
