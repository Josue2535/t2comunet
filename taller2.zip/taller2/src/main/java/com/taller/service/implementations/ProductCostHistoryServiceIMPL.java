package com.taller.service.implementations;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.prod.Productcosthistory;
import com.taller.repository.interfaces.ProductCostHisoryRepository;
import com.taller.service.interfaces.ProductCategoryService;
import com.taller.service.interfaces.ProductCostHistoryService;
import com.taller.service.interfaces.ProductService;
@Service
public class ProductCostHistoryServiceIMPL implements ProductCostHistoryService{
	private ProductCostHisoryRepository repo;
	private ProductService proSer;
	
	@Autowired
	public ProductCostHistoryServiceIMPL(ProductCostHisoryRepository repo, ProductService proSer) {
		this.repo = repo;
		this.proSer = proSer;
	}

	@Override
	public void save(Productcosthistory pch) {
		// TODO Auto-generated method stub
		if(pch.getProduct().getProductid()>0&&pch.getStandardcost()>0) {
			save(pch);
		}else {
			throw new RuntimeException();
		}
	}

	@Override
	public void update(Productcosthistory pch, int id) {
		// TODO Auto-generated method stub
		if(proSer.exist(pch.getProduct().getProductid())&&pch.getStandardcost()>0) {
			repo.findById(id);
		}else {
			throw new RuntimeException();
		}
	}

	public Iterable<Productcosthistory> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public Optional<Productcosthistory> findById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	public void delete(Productcosthistory productcosthistory) {
		// TODO Auto-generated method stub
		repo.delete(productcosthistory);
	}

}
