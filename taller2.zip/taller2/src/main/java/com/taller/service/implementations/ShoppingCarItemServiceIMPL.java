package com.taller.service.implementations;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.sales.Shoppingcartitem;
import com.taller.repository.interfaces.ShoppingCartItemRepository;
import com.taller.service.interfaces.ProductService;
import com.taller.service.interfaces.ShoppingCarItemService;

@Service
public class ShoppingCarItemServiceIMPL implements ShoppingCarItemService {
	private ProductServiceIMPL proSer;
	private ShoppingCartItemRepository repo;

	@Autowired
	public ShoppingCarItemServiceIMPL(ProductServiceIMPL proSer, ShoppingCartItemRepository repo) {
		this.proSer = proSer;
		this.repo = repo;
	}

	@Override
	public void save(Shoppingcartitem sc) {
		// TODO Auto-generated method stub
		if (sc != null) {
			if (proSer.findById(sc.getProductid())!=null && sc.getQuantity() > 0) {
				repo.save(sc);
			} else {
				throw new RuntimeException("MAL");
			}
		} else {
			throw new NullPointerException();
		}
	}

	@Override
	public void update(Shoppingcartitem sc, int id) {
		// TODO Auto-generated method stub
		if(sc!=null) {
		if (proSer.exist(id) && sc.getQuantity() > 0 && id < -1) {
			repo.deleteById(id);
			repo.save(sc);
		} else {
			throw new RuntimeException("MAL");
		}
		}else {
			throw new NullPointerException();
		}

	}

	public Iterable<Shoppingcartitem> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public Optional<Shoppingcartitem> findById(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

	public void delete(Shoppingcartitem shoppingcartitem) {
		// TODO Auto-generated method stub
		repo.delete(shoppingcartitem);
	}

}
