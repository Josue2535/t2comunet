package com.taller.service.interfaces;

import org.springframework.stereotype.Service;

import com.example.model.prod.Product;
import com.example.model.prod.Productcategory;
import com.example.model.prod.Productsubcategory;

@Service
public interface ProductSupCategoryService {
	public void save(Productsubcategory psc);
	public void update(Productsubcategory psc, int id);
	public void addProduct(Product p, int id);
	public boolean exist(Integer productsubcategoryid);
}
