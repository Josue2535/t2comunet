package com.taller.service.interfaces;

import org.springframework.stereotype.Service;

import com.example.model.prod.Product;
import com.example.model.prod.Productsubcategory;

@Service
public interface ProductService {
	public void save(Product p);
	public void update(Product p, int id);
	void save(Product p, int supCategory, int category, int codigo);
	public boolean exist(int id);
	
}
