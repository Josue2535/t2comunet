package com.taller.service.implementations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.prod.Productcategory;
import com.example.model.prod.Productsubcategory;
import com.taller.repository.interfaces.ProductCategoryRepository;
import com.taller.service.interfaces.ProductCategoryService;
import com.taller.service.interfaces.ProductSupCategoryService;

@Service
public class ProductCategoryServiceIMPL implements ProductCategoryService{
	
	private ProductCategoryRepository repo;
	@Autowired
	public ProductCategoryServiceIMPL(ProductCategoryRepository repo) {
		this.repo = repo;
	}

	@Override
	public void save(Productcategory pc) {
		// TODO Auto-generated method stub
		repo.save(pc);
	}

	@Override
	public void update(Productcategory pc, int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		repo.save(pc);
	}

	@Override
	public void addSupCategory(Productsubcategory psc, int id) {
		// TODO Auto-generated method stub
		repo.findById(id).get().addProductsubcategory(psc);
	}

	@Override
	public boolean exist(Integer productcategoryid) {
		// TODO Auto-generated method stub
		return repo.existsById(productcategoryid);
	}

	public Iterable<Productcategory> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
	

}
