package com.taller.service.interfaces;

import org.springframework.stereotype.Service;

import com.example.model.prod.Productcategory;
import com.example.model.prod.Productsubcategory;

@Service
public interface ProductCategoryService {
	public void save(Productcategory pc);
	public void update(Productcategory pc, int id);
	public void addSupCategory(Productsubcategory psc, int id);
	public boolean exist(Integer productcategoryid);
}
