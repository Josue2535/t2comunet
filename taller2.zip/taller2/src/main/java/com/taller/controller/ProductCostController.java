package com.taller.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.hr.info;
import com.example.model.prod.Productcosthistory;
import com.taller.service.implementations.ProductCostHistoryServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;

@Controller
public class ProductCostController {
	//------------------------------------------------------- Services -------------------------------------------------------
		ProductServiceIMPL ps;
		ProductCostHistoryServiceIMPL pchs;
		
		
		//------------------------------------------------------- Constructor -------------------------------------------------------
		@Autowired
		public ProductCostController(ProductServiceIMPL ps, ProductCostHistoryServiceIMPL pchs) {
			this.ps = ps;
			this.pchs = pchs;
		}
		
		//------------------------------------------------------- Index -------------------------------------------------------
		@GetMapping("/productcost")
	    public String Productcost(Model model) {
			model.addAttribute("productcost", pchs.findAll());
	        return "operator/productcost";
	    }
		
		
		
		//------------------------------------------------------- Save -------------------------------------------------------
		
		
		//------------------------------------------------------- Edit -------------------------------------------------------
		@GetMapping("/productcost/edit/{id}")
		public String editproductcost(@PathVariable("id") Integer id, Model model) {
			Productcosthistory pv = pchs.findById(id).get();
			if (pv == null)
				throw new IllegalArgumentException("Invalid product cost Id:" + id);
			
			model.addAttribute("productcost", pv);
			model.addAttribute("products", ps.findAll());
			return "operator/editproductcost";
		}
		
		@PostMapping("/productcost/edit/{id}")
		public String updateproductcost(@PathVariable("id") Integer id, @Validated(info.class) Productcosthistory productcost, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
			if (action.equals("Cancel")) {
				return "redirect:/productcost";
			}
			if(bindingResult.hasErrors()) {
				Productcosthistory pv = pchs.findById(id).get();
				if (pv == null)
					throw new IllegalArgumentException("Invalid product vendor Id:" + id);
				
				model.addAttribute("productcost", pv);
				model.addAttribute("products", ps.findAll());
				return "admin/editproductcost";
			}
			productcost.setId(id);
			pchs.update(productcost, id);
			return "redirect:/productcost";
		}
		
		//------------------------------------------------------- Delete -------------------------------------------------------
		
		@GetMapping("/productvendor/delete/{id}")
		public String deleteproductcost(@PathVariable("id") Integer id, Model model) {
			Optional<Productcosthistory> productcost = pchs.findById(id);
			if (productcost.isEmpty())
				throw new IllegalArgumentException("Invalid product cost Id:" + id);
			
			
			pchs.delete(productcost.get());
			return "redirect:/productcost";
		}
		
		//------------------------------------------------------- Extra methods -------------------------------------------------------
		
}
