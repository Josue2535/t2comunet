package com.taller.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.hr.info;
import com.example.model.prod.Productcosthistory;
import com.example.model.sales.Shoppingcartitem;
import com.taller.service.implementations.ProductCostHistoryServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ShoppingCarItemServiceIMPL;



@Controller
public class OperatorController {
	//------------------------------------------------------- Services -------------------------------------------------------
			ShoppingCarItemServiceIMPL scs;
			
			ProductCostHistoryServiceIMPL pchs;
			
			ProductServiceIMPL ps;
			
			
			//------------------------------------------------------- Constructor -------------------------------------------------------
			@Autowired
			public OperatorController(ShoppingCarItemServiceIMPL scs, ProductCostHistoryServiceIMPL pchs,ProductServiceIMPL ps) {
				this.scs = scs;
				this.pchs = pchs;
				this.ps = ps;
			}
			
			//------------------------------------------------------- Index -------------------------------------------------------
			
			
			//------------------------------------------------------- Save -------------------------------------------------------
			@GetMapping("/productcost/add")
			public String addProductcost(Model model) {
				model.addAttribute("productcost", new Productcosthistory());
				model.addAttribute("products", ps.findAll());
				return "operator/addproductcost";
			}
			
			@PostMapping("/productcost/add")
			public String savepProductcost(@Validated(info.class) Productcosthistory productcost, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
				if (action.equals("Cancel")) {
					return "redirect:/productcost";
					
				}
				
				if(bindingResult.hasErrors()) {
					model.addAttribute("productcost", new Productcosthistory());
					model.addAttribute("products", ps.findAll());
					return "operator/addproductcost";
				}
				
				pchs.save(productcost);
				return "redirect:/productcost";
			}
			
			//------------------------------------------------------- Edit -------------------------------------------------------
			
			
			//------------------------------------------------------- Delete -------------------------------------------------------
			

			//------------------------------------------------------- Extra methods -------------------------------------------------------
			
}
