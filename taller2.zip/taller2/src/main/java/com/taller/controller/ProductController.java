package com.taller.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.hr.info;
import com.example.model.prod.Product;
import com.taller.service.implementations.ProductCategoryServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ProductSupCategoryServiceIMPL;



@Controller
public class ProductController {
	//------------------------------------------------------- Services -------------------------------------------------------
		ProductServiceIMPL ps;
		ProductCategoryServiceIMPL pcs;
		ProductSupCategoryServiceIMPL pscs;

		
		//------------------------------------------------------- Constructor -------------------------------------------------------
		@Autowired
		public ProductController(ProductServiceIMPL ps,  ProductCategoryServiceIMPL pcs, ProductSupCategoryServiceIMPL pscs) {
			this.ps = ps;
			this.pcs = pcs;
			this.pscs = pscs;
		}
		
		//------------------------------------------------------- Index -------------------------------------------------------
		@GetMapping("/product")
	    public String products(Model model) {
			model.addAttribute("products", ps.findAll());
	        return "admin/products";
	    }
		
		
		//------------------------------------------------------- Save -------------------------------------------------------
		@GetMapping("/product/add")
		public String addProduct(Model model) {
			model.addAttribute("product", new Product());
			model.addAttribute("productsubcategories", pscs.findAll());
			return "admin/addProduct";
		}
		
		@PostMapping("/product/add")
		public String saveProduct(@Validated(info.class) Product product, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
			if (action.equals("Cancel")) {
				return "redirect:/product";
			}
			if(bindingResult.hasErrors()) {
				model.addAttribute("product", new Product());
				model.addAttribute("productcategories", pcs.findAll());
				model.addAttribute("productsubcategories", pscs.findAll());
				return "admin/addProduct";
			}
			ps.save(product);
			return "redirect:/product";
		}
		
		//------------------------------------------------------- Edit -------------------------------------------------------
		@GetMapping("/product/edit/{id}")
		public String editProduct(@PathVariable("id") Integer id, Model model) {
			Product p = ps.findById(id).get();
			if (p == null)
				throw new IllegalArgumentException("Invalid product Id:" + id);
			
			model.addAttribute("product", p);
			model.addAttribute("productsubcategories", pscs.findAll());
			return "admin/editProduct";
		}
		
		@PostMapping("/product/edit/{id}")
		public String updateProduct(@PathVariable("id") Integer id, @Validated(info.class) Product product, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
			if (action.equals("Cancel")) {
				return "redirect:/product";
			}
			if(bindingResult.hasErrors()) {
				Product p = ps.findById(id).get();
				if (p == null)
					throw new IllegalArgumentException("Invalid product Id:" + id);
				
				model.addAttribute("product", p);
				model.addAttribute("productsubcategories", pscs.findAll());
				return "admin/editProduct";
			}
			product.setProductid(id);
			ps.update(product, id);
			return "redirect:/product";
		}
		
		//------------------------------------------------------- Delete -------------------------------------------------------
		@GetMapping("/product/delete/{id}")
		public String deleteProduct(@PathVariable("id") Integer id, Model model) {
			Optional<Product> product = ps.findById(id);
			if (product.isEmpty())
				throw new IllegalArgumentException("Invalid product Id:" + id);
			
			
			ps.delete(product.get());
			return "redirect:/product";
		}
		
		//------------------------------------------------------- Extra methods -------------------------------------------------------
		
		
}
