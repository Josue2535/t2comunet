package com.taller.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.hr.info;
import com.example.model.prod.Product;
import com.example.model.prod.Productcategory;
import com.example.model.prod.Productmodel;
import com.example.model.prod.Productsubcategory;
import com.taller.service.implementations.ProductCategoryServiceIMPL;
import com.taller.service.implementations.ProductModelServiceIMPL;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ProductSupCategoryServiceIMPL;

@Controller
public class AdminController {

	// ------------------------------------------------------- Services
	// -------------------------------------------------------
	ProductModelServiceIMPL pms;
	ProductServiceIMPL ps;
	ProductSupCategoryServiceIMPL pss;
	ProductCategoryServiceIMPL pcs;

	// ------------------------------------------------------- Constructor
	// -------------------------------------------------------
	@Autowired
	public AdminController(ProductModelServiceIMPL pms, ProductServiceIMPL ps,ProductSupCategoryServiceIMPL pss, ProductCategoryServiceIMPL pcs) {
		this.pms = pms;
		this.ps = ps;
		this.pss = pss;
		this.pcs = pcs;
	}

	// ------------------------------------------------------- Index
	// -------------------------------------------------------

	// ------------------------------------------------------- Save
	// -------------------------------------------------------
	@GetMapping("/productcategory/add")
	public String addProductcategory(Model model) {
		model.addAttribute("productcategory", new Productcategory());
		return "admin/addProductcategory";
	}
	
	@PostMapping("/productcategory/add")
	public String saveProductcategory(@Validated Productcategory productcategory, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
		if(bindingResult.hasErrors()) {
			model.addAttribute("productcategory", new Productcategory());
			return "admin/addProductcategory";
		}
		
		if (action.equals("Cancel")) {
			return "redirect:/productcategory/add";
		}
		pcs.save(productcategory);
		return "redirect:/productcategory/add";
	}
	
	@GetMapping("/productsubcategory/add")
	public String addProductsubcategory(Model model) {
		model.addAttribute("productsubcategory", new Productsubcategory());
		model.addAttribute("productcategories", pcs.findAll());
		return "admin/addProductsubcategory";
	}
	
	@PostMapping("/productsubcategory/add")
	public String saveProductsubcategory(@Validated Productsubcategory productsubcategory, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
		if(bindingResult.hasErrors()) {
			model.addAttribute("productsubcategory", new Productsubcategory());
			model.addAttribute("productcategories", pcs.findAll());
			return "admin/addProductsubcategory";
		}
		
		if (action.equals("Cancel")) {
			return "redirect:/productsubcategory/add";
		}
		pss.save(productsubcategory);
		return "redirect:/productsubcategory/add";
	}
	@GetMapping("/productmodel")
	public String productsModel(Model model) {
		model.addAttribute("productsmodel", pms.findAll());
		return "admin/productmodel";
	}
	
	@GetMapping("/productmodel/add")
	public String addProductModel(Model model) {
		model.addAttribute("productmodel", new Productmodel());
		return "admin/addProductmodel";
	}

	@PostMapping("/productmodel/add")
	public String saveProductModel(@Validated Productmodel productmodel, BindingResult bindingResult, Model model,
			@RequestParam(value = "action", required = true) String action) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("productmodel", new Productmodel());
			return "admin/productmodel";
		}

		if (action.equals("Cancel")) {
			return "redirect:productmodel/add";
		}
		pms.save(productmodel);
		return "redirect:/admin/productmodel";
	}

	@GetMapping("/productmodel/edit/{id}")
	public String editProductModel(@PathVariable("id") Integer id, Model model) {
		Productmodel p = pms.findById(id).get();
		if (p == null)
			throw new IllegalArgumentException("Invalid product model Id:" + id);
		
		model.addAttribute("productmodel", p);
		return "admin/editProductmodel";
	}
	
	@PostMapping("/productmodel/edit/{id}")
	public String updateProduct(@PathVariable("id") Integer id, @Validated(info.class) Productmodel product, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
		if (action.equals("Cancel")) {
			return "redirect:/product";
		}
		if(bindingResult.hasErrors()) {
			Product p = ps.findById(id).get();
			if (p == null)
				throw new IllegalArgumentException("Invalid product model Id:" + id);
			
			model.addAttribute("productmodel", p);
			return "admin/editProductmodel";
		}
		product.setProductmodelid(id);
		pms.update(id, product);
		return "redirect:/productmodel";
	}
	
	//------------------------------------------------------- Delete -------------------------------------------------------
	@GetMapping("/productmodel/delete/{id}")
	public String deleteProduct(@PathVariable("id") Integer id, Model model) {
		Optional<Productmodel> product = pms.findById(id);
		if (product.isEmpty())
			throw new IllegalArgumentException("Invalid product model Id:" + id);
		
		
		pms.delete(product.get());
		return "redirect:/productmodel";
	}
	

}
