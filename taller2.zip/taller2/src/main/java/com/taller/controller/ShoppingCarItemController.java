package com.taller.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.model.hr.info;
import com.example.model.sales.Shoppingcartitem;
import com.taller.service.implementations.ProductServiceIMPL;
import com.taller.service.implementations.ShoppingCarItemServiceIMPL;

@Controller
public class ShoppingCarItemController {
	//------------------------------------------------------- Services -------------------------------------------------------
		ShoppingCarItemServiceIMPL scis;
		
		ProductServiceIMPL ps;
		
		//------------------------------------------------------- Constructor -------------------------------------------------------
		@Autowired
		public ShoppingCarItemController(ShoppingCarItemServiceIMPL scis, ProductServiceIMPL ps) {
			this.scis = scis;
			this.ps = ps;
		}
		
		//------------------------------------------------------- Index -------------------------------------------------------
		@GetMapping("/shoppingcar")
	    public String shoppingcar(Model model) {
			model.addAttribute("shoppingcar", scis.findAll());
	        return "operator/shoppingcar";
	    }
		
		
		//------------------------------------------------------- Save -------------------------------------------------------
		@GetMapping("/shoppingcar/add")
		public String addShoppingcar(Model model) {
			model.addAttribute("shoppingcar", new Shoppingcartitem());
			model.addAttribute("products", ps.findAll());
			return "operator/addshoppingcar";
		}
		
		@PostMapping("/shoppingcar/add")
		public String saveShoppingcar(Shoppingcartitem shopping, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
			if (action.equals("Cancel")) {
				return "redirect:/shoppingcar";
			}
			
			if(bindingResult.hasErrors()) {
				model.addAttribute("shoppingcar", new Shoppingcartitem());
				model.addAttribute("products", ps.findAll());
				return "operator/addshoppingcar";
			}
			
			scis.save(shopping);
			return "redirect:/shoppingcar";
		}
		
		//------------------------------------------------------- Edit -------------------------------------------------------
		@PostMapping("/shoppingcar/edit/{id}")
		public String updateShoppingcar(@PathVariable("id") Integer id, @Validated(info.class) Shoppingcartitem shopping, BindingResult bindingResult, Model model, @RequestParam(value = "action", required = true) String action) {
			if (action.equals("Cancel")) {
				return "redirect:/shoppingcar";
			}
			if(bindingResult.hasErrors()) {
				Shoppingcartitem th = scis.findById(id).get();
				if (th == null)
					throw new IllegalArgumentException("Invalid transaction history Id:" + id);
				
				model.addAttribute("shoppingcar", th);
				model.addAttribute("products", ps.findAll());
				return "operator/editshoppingcar";
			}
			shopping.setShoppingcartitemid(id);
			scis.update(shopping, id);
			return "redirect:/shoppingcar";
		}
		
		//------------------------------------------------------- Delete -------------------------------------------------------
		@GetMapping("/shoppingcar/delete/{id}")
		public String deleteTransactionhistory(@PathVariable("id") Integer id, Model model) {
			Optional<Shoppingcartitem> shopping = scis.findById(id);
			if (shopping.isEmpty())
				throw new IllegalArgumentException("Invalid transaction history Id:" + id);
			
			
			scis.delete(shopping.get());
			return "redirect:/shoppingcar";
		}
		
		//------------------------------------------------------- Extra methods -------------------------------------------------------
		
}
