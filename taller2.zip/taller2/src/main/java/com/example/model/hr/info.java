package com.example.model.hr;

public interface info {

}
